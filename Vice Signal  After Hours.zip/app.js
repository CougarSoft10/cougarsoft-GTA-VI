const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const DATA=window.HUB_DATA;
function readStore(key,fallback){try{return JSON.parse(localStorage.getItem('afterhours-'+key))??fallback}catch{return fallback}}
function writeStore(key,value){try{localStorage.setItem('afterhours-'+key,JSON.stringify(value))}catch{}}
const savedVehicles=new Set(readStore('garage',[]));
let selectedScene=0;
const icons={
 car:'<svg viewBox="0 0 100 60" aria-hidden="true"><path d="M13 40V28l14-5 10-14h31l14 17 8 4v12H13zM30 23h46M43 10l-7 13m24-13 3 13"/><circle cx="29" cy="42" r="8"/><circle cx="73" cy="42" r="8"/></svg>',
 gun:'<svg viewBox="0 0 100 60" aria-hidden="true"><path d="M10 16h73v8H51l-3 10H34l-4 19H14l8-29H10zm27 10v6h8"/></svg>',
 cassette:'<svg viewBox="0 0 40 40" aria-hidden="true"><rect x="4" y="9" width="32" height="23" rx="3"/><path d="M11 32l4-8h10l4 8M10 14h20v7H10z"/><circle cx="14" cy="17.5" r="2"/><circle cx="26" cy="17.5" r="2"/></svg>',
 flamingo:'<svg viewBox="0 0 40 40" aria-hidden="true"><path d="M20 27v10m4-11 4 10h-7M12 20c-7 8 7 14 15 5-2-5-8-5-9-9-2-4 4-4 6-8 3-5-6-6-7-1m7 1 7 2-5 3"/></svg>',
 money:'<svg viewBox="0 0 40 40" aria-hidden="true"><rect x="3" y="10" width="34" height="20" rx="2"/><circle cx="20" cy="20" r="7"/><path d="M20 14v12m3-10h-4c-4 0-4 4 0 4h2c4 0 4 4 0 4h-4M7 16v8m26-8v8"/></svg>',
 spray:'<svg viewBox="0 0 40 40" aria-hidden="true"><rect x="12" y="13" width="16" height="24" rx="3"/><path d="M15 13V8h10v5M18 8V4h7v4m5-4h5m-6 4 5 3M12 19h16m-16 12h16"/></svg>',
 star:'<svg viewBox="0 0 40 40" aria-hidden="true"><path d="m20 3 5 10 12 2-8 9 2 12-11-6-11 6 2-12-8-9 12-2z"/><circle cx="20" cy="21" r="5"/></svg>',
 dice:'<svg viewBox="0 0 40 40" aria-hidden="true"><rect x="7" y="7" width="26" height="26" rx="4"/><circle cx="14" cy="14" r="1.7"/><circle cx="26" cy="14" r="1.7"/><circle cx="20" cy="20" r="1.7"/><circle cx="14" cy="26" r="1.7"/><circle cx="26" cy="26" r="1.7"/></svg>'
};
const statusText=s=>s==='shown'?'Official visuals':s==='leaked'?'Leak report':'Unverified';
const statusHTML=s=>`<span class="status ${s}">${statusText(s)}</span>`;
function toast(s){$('#toast').textContent=s;$('#toast').classList.add('visible');clearTimeout(window.toastTimer);window.toastTimer=setTimeout(()=>$('#toast').classList.remove('visible'),3200)}
function modal(content){$('#dialog-content').innerHTML=content;$('#dialog').showModal()}
$('.close').onclick=()=>$('#dialog').close();
$('#dialog').addEventListener('click',e=>{if(e.target===$('#dialog'))$('#dialog').close()});
$('#about-button').onclick=()=>modal(`<span class="status">Independent fan project</span><h2>Same city. Our frequency.</h2><p>Vice Signal is a fan-made GTA VI companion, not an official Rockstar product. Grand Theft Auto, its characters, and promotional artwork belong to Rockstar Games and Take-Two Interactive.</p><p>Artwork: <a href="https://www.rockstargames.com/VI" target="_blank" rel="noopener">Rockstar Games official GTA VI website</a>. Vehicle index: <a href="https://gta.wiki/w/Vehicles_in_GTA_VI" target="_blank" rel="noopener">GTA Wiki</a>. Vehicle imagery and weapon identifications: <a href="https://www.gtabase.com/gta-6/vehicles/" target="_blank" rel="noopener">GTA Base vehicles</a> and <a href="https://www.gtabase.com/gta-6/weapons/" target="_blank" rel="noopener">weapons database</a>.</p><p>“Official visuals” means a community identification in released promotional material, not an officially announced model name. “Leak report” means pre-release reporting, not a guarantee of final content. Source pages may evolve after this build.</p><p>Release target verified against <a href="https://www.rockstargames.com/VI" target="_blank" rel="noopener">Rockstar's official site</a>. Research snapshot: 1 November 2026. This archive cannot guarantee a complete final-game roster.</p><p>All radio tracks are original procedural instrumentals made for this project. Station names, track names, and the easter egg hunt are fan creations, not GTA VI announcements. Progress lasts for this browser session; no personal data is collected.</p>`);
function home(){
 return `<div class="view"><section class="hero"><div class="hero-media"><img src="assets/vice.webp" alt="Rockstar artwork of Lucia and Jason in Vice City" fetchpriority="high"></div><div class="hero-copy"><h1>GOOD THINGS.<br>BAD PEOPLE.</h1><p>All roads lead to Leonida. Your independent signal for everything GTA VI, while we wait.</p><div class="hero-actions"><button class="primary" data-tune>Tune into Vice FM <span>↗</span></button><a href="#vehicles" class="plain-link">Explore the archive ↗</a></div><div class="hero-bottom"><a href="#vehicles"><strong>${DATA.vehicles.length}</strong>Vehicles indexed</a><a href="#weapons"><strong>${DATA.weapons.length}</strong>Weapons tracked</a><a href="#hunt"><strong>6</strong>Secrets to find</a></div></div><span class="hero-stamp">LEONIDA, USA &nbsp; / &nbsp; UNOFFICIAL FAN HUB</span></section><aside class="release-strip"><p><strong>THE WAIT HAS A DATE.</strong> &nbsp; GTA VI is scheduled for November 19, 2026.</p><a href="#timeline">The road to release ↗</a></aside><section class="section"><div class="section-head"><h2>Pick your next move.</h2><p>A little less refreshing the Newswire.<br>A little more getting lost in Leonida.</p></div><div class="explore-grid"><a href="#radio" class="feature radio-feature"><div class="radio-disc ${radio.playing?'playing':''}"></div><span class="feature-arrow">↗</span><div class="feature-copy"><span>01 / ON YOUR FREQUENCY</span><h3>Soundtrack the wait.</h3><p>Three fan stations. Twelve original instrumentals.<br>Good music. No wanted level.</p></div></a><a href="#vehicles" class="feature"><img src="assets/hero.webp" alt="A collage of GTA VI cars, bikes and boats" loading="lazy" style="object-position:30% 70%"><span class="feature-arrow">↗</span><div class="feature-copy"><span>02 / THE GARAGE</span><h3>Your next getaway.</h3><p>The wheels, wings and watercraft spotted so far.</p></div></a><a href="#hunt" class="feature"><img src="assets/leonida.webp" alt="A man floating in a swimming pool in official Leonida artwork" loading="lazy"><span class="feature-arrow">↗</span><div class="feature-copy"><span>03 / SIDE MISSION</span><h3>Nothing to see here.</h3><p>Six hidden collectibles. One familiar feeling.</p></div></a></div></section><section class="section story-section"><img class="story-art" src="assets/trailer.webp" alt="Jason and Lucia in Rockstar's second trailer artwork" loading="lazy"><div class="story-copy"><span class="status">THE ARCHIVE / NO RUMOUR FOG</span><h2>Know the facts.<br>Keep the theories.</h2><p>From the first announcement to the latest release target, follow the road to GTA VI. Every roster entry distinguishes official visuals from leak reports, with evidence a click away.</p><a class="plain-link" href="#timeline">Catch up on the timeline ↗</a></div></section></div>`;
}
const rosterState={vehicles:{q:'',category:'All classes',status:'all',limit:24},weapons:{q:'',category:'All classes',status:'all',limit:24}};
let currentRoute='home';
function roster(kind){
 const isVehicle=kind==='vehicles', items=DATA[kind],state=rosterState[kind],cats=[...new Set(items.map(v=>v.category))].sort();
 return `<div class="view"><section class="page-intro"><div><h1>${isVehicle?'The getaway garage.':'The weapons locker.'}</h1><p>${isVehicle?'Every vehicle in our sourced pre-release index. From Ocean Drive cruisers to your very questionable escape plan.':'The weapons spotted and reported so far. Official visuals and pre-release leak reports, kept on separate shelves.'}</p></div><div class="intro-stat">${items.length}<span>${isVehicle?'vehicles':'weapons'} indexed</span></div></section><section class="section archive-section"><div class="notice">Not a final-game roster. “Official visuals” indicates a fan identification in promotional material, not an official name or a final-content guarantee. Leaks may be cut or changed. Snapshot: 1 Nov 2026. <a href="${isVehicle?'https://gta.wiki/w/Vehicles_in_GTA_VI':'https://www.gtabase.com/gta-6/weapons/'}" target="_blank" rel="noopener">Browse the source index ↗</a></div><div class="filter-bar"><input type="search" id="roster-search" aria-label="Search ${kind}" placeholder="Search by name, class or real-world counterpart…" value="${esc(state.q)}"><select id="class-filter" aria-label="Vehicle or weapon class"><option>All classes</option>${cats.map(c=>`<option${state.category===c?' selected':''}>${esc(c)}</option>`).join('')}</select><button data-status="all">All evidence</button><button data-status="shown">Official visuals</button><button data-status="leaked">Leak reports</button></div><div class="result-line"><span id="results-count"></span><span>A–Z / click any entry for evidence</span></div><div id="roster-results" class="roster-grid"></div><button class="primary load-more" id="load-more">Load more entries <span>↓</span></button></section></div>`;
}
function renderResults(){
 const s=rosterState[currentRoute],items=DATA[currentRoute];
 const filtered=items.filter(v=>(s.category==='All classes'||v.category===s.category)&&(s.status==='all'||v.status===s.status)&&`${v.name} ${v.category} ${v.inspiration}`.toLowerCase().includes(s.q.toLowerCase())).sort((a,b)=>a.name.localeCompare(b.name));
 $('#results-count').textContent=`${filtered.length} ${filtered.length===1?'match':'matches'} · showing ${Math.min(filtered.length,s.limit)}`;
 $$('[data-status]').forEach(b=>{b.classList.toggle('selected',b.dataset.status===s.status);b.setAttribute('aria-pressed',b.dataset.status===s.status)});
 const results=$('#roster-results');
 results.innerHTML=filtered.length?filtered.slice(0,s.limit).map(v=>{let i=items.indexOf(v);return `<button class="roster-item" data-entry="${i}">${v.image?`<img src="${esc(v.image)}" alt="${esc(v.name)}" class="roster-image" loading="lazy" decoding="async">`:`<div class="roster-placeholder">${icons[v.kind==='vehicle'?'car':'gun']}</div>`}<div class="roster-info"><span class="category">${esc(v.category)}</span><h3>${esc(v.name)}</h3>${statusHTML(v.status)}</div></button>`}).join(''):`<div class="empty" style="grid-column:1/-1"><h3>No signal found.</h3><p>Try a different name or clear your filters.</p><button class="text-button" id="reset-filters">Clear filters ↗</button></div>`;
 $('#load-more').hidden=filtered.length<=s.limit;
 results.querySelectorAll('img').forEach(img=>img.onerror=()=>{img.outerHTML=`<div class="roster-placeholder">${icons[currentRoute==='vehicles'?'car':'gun']}</div>`});
 $$('[data-entry]').forEach(b=>b.onclick=()=>showEntry(items[+b.dataset.entry]));
 if($('#reset-filters'))$('#reset-filters').onclick=()=>{Object.assign(s,{q:'',category:'All classes',status:'all',limit:24});$('#roster-search').value='';$('#class-filter').value='All classes';renderResults()};
}
function showEntry(v){
 modal(`${statusHTML(v.status)}<h2>${esc(v.name)}</h2>${v.image?`<img class="detail-img" src="${esc(v.image)}" alt="${esc(v.name)}">`:''}<dl><dt>Class</dt><dd>${esc(v.category)}</dd><dt>Evidence</dt><dd>${esc(v.evidence)}</dd>${v.inspiration?`<dt>Based on</dt><dd>${esc(v.inspiration)}</dd>`:''}<dt>Availability</dt><dd>Pre-release identification. Final inclusion, name and statistics are not guaranteed.</dd></dl><p>${v.status==='leaked'?'This entry is reported from pre-release leaks. Early development content can change or disappear.':'Model names are community identifications unless Rockstar has explicitly named them.'}</p><p><a href="${esc(v.detailSource||v.source)}" target="_blank" rel="noopener">View the identification source ↗</a></p><p><a href="${esc(v.source)}" target="_blank" rel="noopener">Open the full source index ↗</a></p>`);
 const img=$('#dialog .detail-img');if(img)img.onerror=()=>img.remove();
 if(v.kind==='vehicle'){
  $('#dialog-content').insertAdjacentHTML('beforeend',`<button class="save-entry" id="save-entry" aria-pressed="${savedVehicles.has(v.name)}">${savedVehicles.has(v.name)?'Saved to your garage':'Save to your garage +'}</button>`);
  $('#save-entry').onclick=()=>{
   if(savedVehicles.has(v.name))savedVehicles.delete(v.name);else savedVehicles.add(v.name);
   writeStore('garage',[...savedVehicles]);$('#save-entry').setAttribute('aria-pressed',savedVehicles.has(v.name));$('#save-entry').textContent=savedVehicles.has(v.name)?'Saved to your garage':'Save to your garage +';
   if($('#saved-garage'))$('#saved-garage').textContent=`Saved garage (${savedVehicles.size})`;
   toast(savedVehicles.has(v.name)?`${v.name} saved to your garage.`:`${v.name} removed from your garage.`);
  };
 }
}
const stations=[
 {name:'VICE FM',freq:'98.6',tag:'Sun down. Volume up.',color:'#ff9bb8',style:'Warm synthwave / coastal cruising',tracks:[['Ocean Drive',0],['Heat Haze',1],['Pink Horizon',2],['Last Exit to Leonida',3]]},
 {name:'NIGHT RIDE',freq:'103.2',tag:'The city never sleeps.',color:'#c8d9af',style:'After-dark electronics / midnight highways',tracks:[['Midnight Toll',4],['Neon Getaway',5],['No Witnesses',6],['Rearview Lights',7]]},
 {name:'LOWLIFE FM',freq:'106.9',tag:'Good taste. Bad company.',color:'#efac79',style:'Low-slung beats / slow-lane mischief',tracks:[['Sunset Hustle',8],['Corner Store',9],['Cash Only',10],['Southside Shuffle',11]]}
];
const radio={station:0,track:0,playing:false,position:0,started:0,ctx:null,master:null,interval:null,step:0,nextTime:0,shuffle:false};
const title=()=>stations[radio.station].tracks[radio.track][0];
const fmt=t=>`${Math.floor(t/60)}:${String(Math.floor(t%60)).padStart(2,'0')}`;
function legacyRadioPage(){
 let s=stations[radio.station];
 return `<div class="view"><section class="page-intro"><div><h1>Stay on the frequency.</h1><p>The sound of a city you haven’t driven through yet. Three independent fan stations, broadcasting original instrumentals.</p></div><div class="intro-stat">FM<span>FAN MIX / NOT AN OFFICIAL SOUNDTRACK</span></div></section><section class="radio-layout"><div class="radio-left"><div class="station-art" style="background:${s.color}"><h2>${s.name.replace(' ','<br>')}<small style="display:block;font-size:28px;margin-top:18px">${s.freq}</small></h2><div class="radio-disc ${radio.playing?'playing':''}"></div><p>${s.tag}</p></div><div class="station-tabs" role="group" aria-label="Radio stations">${stations.map((v,i)=>`<button data-station="${i}" class="${radio.station===i?'selected':''}" aria-pressed="${radio.station===i}">${v.name}</button>`).join('')}</div><p class="station-note">Fan-made stations, not Rockstar announcements. All twelve tracks are original, procedurally played 96-second synth loops. No external streams or copyrighted recordings.</p></div><div><div class="playlist-head"><h2>Your next 96 seconds.</h2><button id="shuffle" aria-pressed="${radio.shuffle}">Shuffle: ${radio.shuffle?'on':'off'}</button></div><p class="muted" style="margin-bottom:25px">${s.style}</p><div id="playlist">${s.tracks.map((t,i)=>`<button class="track ${radio.track===i?'current':''}" data-track="${i}" aria-label="Play ${t[0]}"><span class="track-play">${radio.track===i&&radio.playing?'Ⅱ':String(i+1).padStart(2,'0')}</span><span><strong>${t[0]}</strong><small>Vice Signal house band · Original synth loop</small></span><span class="track-time">1:36</span></button>`).join('')}</div><div class="radio-title-action"><button class="primary" id="big-play">${radio.playing?'Pause broadcast':'Start listening'} <span>${radio.playing?'Ⅱ':'▶'}</span></button></div><p class="audio-status">${radio.playing?'Broadcasting now.':'Ready when you are. Press play to start audio.'} Use the player below to seek, skip or change the volume.</p></div></section></div>`;
}
function initAudio(){
 if(radio.ctx)return;
 const C=window.AudioContext||window.webkitAudioContext;
 if(!C)throw new Error('This browser does not support Web Audio.');
 radio.ctx=new C();radio.master=radio.ctx.createGain();radio.master.gain.value=+$('#volume').value/100*.58;radio.master.connect(radio.ctx.destination);
}
function tone(freq,start,duration,type='sine',level=.15){
 const c=radio.ctx,o=c.createOscillator(),g=c.createGain();o.type=type;o.frequency.value=freq;g.gain.setValueAtTime(0,start);g.gain.linearRampToValueAtTime(level,start+.018);g.gain.exponentialRampToValueAtTime(.001,start+duration);o.connect(g);g.connect(radio.master);o.start(start);o.stop(start+duration+.02);
}
function drum(start,kind){
 const c=radio.ctx;
 if(kind==='kick'){let o=c.createOscillator(),g=c.createGain();o.frequency.setValueAtTime(135,start);o.frequency.exponentialRampToValueAtTime(38,start+.12);g.gain.setValueAtTime(.6,start);g.gain.exponentialRampToValueAtTime(.001,start+.25);o.connect(g);g.connect(radio.master);o.start(start);o.stop(start+.27)}
 else{let buffer=c.createBuffer(1,c.sampleRate*.09,c.sampleRate),d=buffer.getChannelData(0);for(let i=0;i<d.length;i++)d[i]=(Math.random()*2-1);let src=c.createBufferSource(),g=c.createGain(),f=c.createBiquadFilter();src.buffer=buffer;f.type='highpass';f.frequency.value=kind==='hat'?8000:1800;g.gain.setValueAtTime(kind==='hat'?.055:.14,start);g.gain.exponentialRampToValueAtTime(.001,start+.075);src.connect(f);f.connect(g);g.connect(radio.master);src.start(start)}
}
function scheduleAudio(){
 if(!radio.playing)return;
 const c=radio.ctx,id=stations[radio.station].tracks[radio.track][1],tempo=[100,108,96,112,120,116,110,124,88,92,84,96][id],stepDuration=60/tempo/4;
 const roots=[130.81,146.83,110,164.81,123.47,138.59,103.83,146.83,98,110,82.41,130.81],root=roots[id],progression=[0,8,3,10];
 while(radio.nextTime<c.currentTime+.13){
  const step=radio.step%64,t=radio.nextTime,chord=progression[Math.floor(step/16)],r=root*2**(chord/12);
  if(step%16===0)[0,3,7].forEach((n,i)=>tone(r*2**(n/12),t+i*.012,stepDuration*14,'triangle',.043));
  if(step%4===0)drum(t,'kick');if(step%8===4)drum(t,'snare');if(step%2===0)drum(t,'hat');
  if(step%4===0||step%16===10)tone(r/2,t,stepDuration*2.6,'sawtooth',.065);
  const pattern=[0,7,12,3,7,15,12,7,0,3,10,7,15,12,7,3];if((step+id)%2===0)tone(r*2**(pattern[Math.floor(step/2)%16]/12),t,stepDuration*1.7,id<4?'triangle':'sine',.075);
  radio.step++;radio.nextTime+=stepDuration;
 }
}
async function setPlaying(playing){
 try{
  initAudio();
  if(playing){await radio.ctx.resume();radio.playing=true;radio.started=performance.now()-radio.position*1000;radio.nextTime=radio.ctx.currentTime+.04;radio.step=Math.floor(radio.position*7);clearInterval(radio.interval);radio.interval=setInterval(scheduleAudio,25);scheduleAudio()}
  else{radio.position=(performance.now()-radio.started)/1000;radio.playing=false;clearInterval(radio.interval);await radio.ctx.suspend()}
  updatePlayer();if(currentRoute==='radio')renderRadio();
 }catch(e){radio.playing=false;toast('Audio could not start. Try pressing play again.');updatePlayer()}
}
function nextTrack(delta=1){
 radio.track=radio.shuffle?(radio.track+1+Math.floor(Math.random()*3))%4:(radio.track+delta+4)%4;radio.position=0;radio.started=performance.now();
 if(radio.ctx){radio.nextTime=radio.ctx.currentTime+.15;radio.step=0}
 updatePlayer();if(currentRoute==='radio')renderRadio();
}
function updatePlayer(){
 document.body.classList.toggle('player-visible',radio.playing||!!radio.ctx||currentRoute==='radio');
 $('#mini-title').textContent=title();$('#mini-sub').textContent=`${stations[radio.station].name} · Fan mix`;
 $('#play').textContent=radio.playing?'Ⅱ':'▶';$('#play').setAttribute('aria-label',radio.playing?'Pause radio':'Play radio');
 $('#air-dot').classList.toggle('live',radio.playing);$('#air-text').textContent=radio.playing?'On air':'Off air';
 $$('.radio-disc').forEach(d=>d.classList.toggle('playing',radio.playing));
 if($('#home-song'))$('#home-song').textContent=title();
 if($('#home-play')){$('#home-play').textContent=radio.playing?'Ⅱ':'▶';$('#home-play').setAttribute('aria-label',radio.playing?'Pause fan radio':'Play fan radio')}
 $$('[data-home-station]').forEach(b=>{b.classList.toggle('selected',+b.dataset.homeStation===radio.station);b.setAttribute('aria-pressed',+b.dataset.homeStation===radio.station)});
 if($('.mini-art img'))$('.mini-art img').src=['assets/music.webp','assets/featured.webp','assets/media.webp'][radio.station];
}
$('#play').onclick=()=>setPlaying(!radio.playing);$('#next').onclick=()=>nextTrack(1);$('#prev').onclick=()=>nextTrack(-1);
$$('[data-open-radio]').forEach(b=>b.onclick=()=>{location.hash='radio'});
$('#volume').oninput=e=>{if(radio.master)radio.master.gain.setTargetAtTime(+e.target.value/100*.58,radio.ctx.currentTime,.02)};
let previousVolume=55;
$('#mute').onclick=()=>{let v=$('#volume');if(+v.value){previousVolume=+v.value;v.value=0;$('#mute').setAttribute('aria-label','Unmute radio')}else{v.value=previousVolume;$('#mute').setAttribute('aria-label','Mute radio')}v.dispatchEvent(new Event('input'))};
$('#seek').oninput=e=>{radio.position=+e.target.value;radio.started=performance.now()-radio.position*1000;if(radio.ctx){radio.nextTime=radio.ctx.currentTime+.15;radio.step=Math.floor(radio.position*7)}$('#elapsed').textContent=fmt(radio.position)};
setInterval(()=>{if(!radio.playing)return;radio.position=(performance.now()-radio.started)/1000;if(radio.position>=96)nextTrack();$('#seek').value=radio.position;$('#elapsed').textContent=fmt(radio.position);if($('#studio-seek')){$('#studio-seek').value=radio.position;$('#studio-elapsed').textContent=fmt(radio.position)}},250);
function renderRadio(){const y=scrollY;$('#main').innerHTML=radioPage();bindRadio();scrollTo(0,y)}
function bindRadio(){
 $('.radio-title-action').insertAdjacentHTML('afterend',`<div class="studio-progress"><span id="studio-elapsed">${fmt(radio.position)}</span><input id="studio-seek" type="range" min="0" max="96" value="${radio.position}" aria-label="Track position"><span>1:36</span></div>`);
 $('#studio-seek').oninput=e=>{$('#seek').value=e.target.value;$('#seek').dispatchEvent(new Event('input'));$('#studio-elapsed').textContent=fmt(radio.position)};
 $$('[data-station]').forEach(b=>b.onclick=()=>{radio.station=+b.dataset.station;radio.track=0;radio.position=0;radio.started=performance.now();if(radio.ctx){radio.nextTime=radio.ctx.currentTime+.15;radio.step=0}updatePlayer();renderRadio()});
 $$('[data-track]').forEach(b=>b.onclick=()=>{const i=+b.dataset.track;if(radio.track===i&&radio.playing){setPlaying(false);return}radio.track=i;radio.position=0;setPlaying(true)});
 $('#big-play').onclick=()=>setPlaying(!radio.playing);
 $('#shuffle').onclick=()=>{radio.shuffle=!radio.shuffle;renderRadio()};
 if($('#station-dial'))$('#station-dial').onchange=e=>{const b=$(`[data-station="${e.target.value}"]`);if(b)b.click()};
}
const events=[
 {date:'04 FEB 2022',title:'The next chapter is real.',text:'Rockstar confirms that active development of the next Grand Theft Auto is “well underway.” No title, trailer or release date yet.',url:'https://www.rockstargames.com/newswire/article/ak73k92o47ko75/grand-theft-auto-community-update',label:'Rockstar community update'},
 {date:'19 SEP 2022',title:'Rockstar addresses the breach.',text:'Rockstar acknowledges a network intrusion and early development footage. This is the origin of many early leak-only roster identifications.',url:'https://www.ign.com/articles/grand-theft-auto-6-leaks-everything-thats-happened-so-far',label:'Rockstar’s statement, via IGN'},
 {date:'08 NOV 2023',title:'December. First trailer.',text:'For Rockstar’s 25th anniversary, Sam Houser announces that a first look at the next Grand Theft Auto will arrive in early December.',url:'https://www.rockstargames.com/newswire/article/4kok877a13aa32/a-message-from-rockstar-games',label:'A message from Rockstar Games'},
 {date:'04 DEC 2023',title:'Welcome back to Vice City.',text:'Trailer 1 arrives early after a leak. GTA VI is revealed with Lucia, Leonida and an initial 2025 release window.',url:'https://www.rockstargames.com/videos/666666',label:'Watch the official first trailer'},
 {date:'16 MAY 2024',title:'A narrower window: fall 2025.',text:'Take-Two narrows the previously announced 2025 window to fall 2025.',url:'https://www.vice-atlas.com/briefings/gta6-marketing-timeline/',label:'Release-window history, via Vice Atlas'},
 {date:'02 MAY 2025',title:'More time in the shop.',text:'The first major delay moves release from fall 2025 to May 26, 2026, allowing Rockstar more time to realize its creative vision.',url:'https://rockstarreport.com/features/gta-6-release-date-tracker',label:'Delay history, via Rockstar Report',type:'delay'},
 {date:'06 MAY 2025',title:'Jason. Lucia. Trailer 2.',text:'The second trailer introduces more of Jason and Lucia’s story, alongside a refreshed website, characters, locations and screenshots.',url:'https://www.rockstargames.com/VI',label:'Explore Rockstar’s GTA VI site'},
 {date:'06 NOV 2025',title:'A new date for Leonida.',text:'Rockstar announces another delay, moving GTA VI from May 26 to November 19, 2026 for additional polish.',url:'https://rockstarreport.com/features/gta-6-release-date-tracker',label:'Release announcement history, via Rockstar Report',type:'delay'},
 {date:'18 JUN 2026',title:'The cover. The next step.',text:'Rockstar reveals the cover artwork and announces that pre-orders open on June 25. The November 19 release target remains in place.',url:'https://www.rockstargames.com/newswire/article/5171972o3ak5oa/pre-order-grand-theft-auto-vi-on-june-25',label:'Rockstar pre-order announcement'},
 {date:'27 AUG 2026',title:'A longer look at Leonida.',text:'GTA VI: An Extended Look arrives, giving fans a substantially longer in-game presentation and reaffirming the November release date.',url:'https://rockstarreport.com/features/gta-6-release-date-tracker',label:'Official-video timeline, via Rockstar Report'},
 {date:'17 SEP 2026',title:'The album is announced.',text:'Rockstar announces a 34-track companion album with Atlantic Records, scheduled alongside the game. A companion album is not the same thing as the full in-game radio catalogue.',url:'https://www.vice-atlas.com/briefings/gta6-marketing-timeline/',label:'Album announcement, via Vice Atlas'},
 {date:'15 OCT 2026',title:'The launch trailer lands.',text:'A new 90-second launch trailer arrives, once again ending on the November 19 release date.',url:'https://www.vice-atlas.com/briefings/gta6-marketing-timeline/',label:'Launch trailer record, via Vice Atlas'},
 {date:'19 NOV 2026',title:'The current destination.',text:'The scheduled release date displayed on Rockstar’s official site. This is a target, not a claim that the game is already available.',url:'https://www.rockstargames.com/VI',label:'Check the latest official date',type:'release'}
];
function timeline(){
 return `<div class="view"><section class="page-intro"><div><h1>A long road to Leonida.</h1><p>The announcements. The trailers. The “we need a little more time.” A sourced history of the wait, through 1 November 2026.</p></div></section><section class="timeline-layout"><div class="timeline-poster"><img src="assets/vice.webp" alt="Official GTA VI artwork of Lucia and Jason"><p class="station-note">No invented countdowns. No rumour dates.<br>The current release target comes from <a href="https://www.rockstargames.com/VI" target="_blank" rel="noopener" style="color:var(--pink)">Rockstar’s official website ↗</a>.</p></div><div>${events.map(e=>`<article class="timeline-event ${e.type||''}"><time>${e.date}</time><div><h2>${e.title}</h2><p>${e.text}</p><a href="${e.url}" target="_blank" rel="noopener">${e.label} ↗</a></div></article>`).join('')}</div></section></div>`;
}
const objects=[
 {name:'The lost mixtape',icon:'cassette',clue:'A little air support for the soundtrack.',x:10,y:17},
 {name:'Lawn royalty',icon:'flamingo',clue:'A pink bird likes a fast boat.',x:63,y:16},
 {name:'Petty cash',icon:'money',clue:'Somebody near the bank dropped this.',x:89,y:23},
 {name:'Fresh paint',icon:'spray',clue:'A golden getaway needs a touch-up.',x:28,y:77},
 {name:'Five-star service',icon:'star',clue:'Check the water. Mind the teeth.',x:56,y:85},
 {name:'A lucky roll',icon:'dice',clue:'Two wheels. A pair of sixes.',x:92,y:79}
];
const game={active:false,complete:false,found:new Set(),start:0,seconds:0,hints:0,best:readStore('best',null)};
let gameInterval;
function hunt(){
 return `<div class="view"><section class="page-intro"><div><h1>Look a little closer.</h1><p>A loading screen with unfinished business. Six objects are hiding in plain sight. Find them all and earn your mission passed.</p></div><div class="intro-stat">SIDE<span>MISSION / THE LOADING SCREEN HUNT</span></div></section><section class="hunt-wrap"><div class="hunt-toolbar"><span class="score"><span id="found-count">${game.found.size}</span> / 6 COLLECTED</span><span class="timer" id="game-time">${fmt(game.seconds)}</span><button id="hint-button">Get a hint${game.hints?' ('+game.hints+')':''}</button><button id="restart-button">Restart ↻</button></div><div class="game-stage"><img class="game-bg" src="assets/hero.webp" alt="Illustrated collage of GTA VI characters, a helicopter, speedboat, cars, an alligator and a motorcycle">${objects.map((o,i)=>`<button class="game-object ${game.found.has(i)?'found':''}" data-object="${i}" aria-label="${o.name}${game.found.has(i)?', collected':''}" aria-disabled="${game.found.has(i)}" style="left:${o.x}%;top:${o.y}%" ${!game.active||game.complete?'tabindex="-1"':''}>${icons[o.icon]}</button>`).join('')}${!game.active&&!game.complete?`<div class="game-overlay"><h2>One more side mission.</h2><p>Find the six collectible objects hidden in the artwork. Use the clues below, or Tab through the scene for keyboard play. The clock starts when you do.</p><button class="primary" id="start-hunt">Start the hunt <span>↗</span></button></div>`:game.complete?completeOverlay():''}</div><div class="hunt-clues">${objects.map((o,i)=>`<div class="clue ${game.found.has(i)?'collected':''}" data-clue="${i}">${icons[o.icon]}<span><strong>${o.name}${game.found.has(i)?'':''}</strong>${o.clue}</span></div>`).join('')}</div><p class="hunt-caption">An original fan mini-game, not a list of actual GTA VI easter eggs. Artwork © Rockstar Games. ${game.best!==null?'Session best: '+fmt(game.best)+'.':''} Timer pauses while you explore the rest of the hub.</p></section></div>`;
}
function completeOverlay(){
 return `<div class="game-overlay"><h2>Mission passed.</h2><p>All six collectibles found in ${fmt(game.seconds)}. ${game.hints?`${game.hints} hint${game.hints===1?'':'s'} used.`:'No hints. Just good instincts.'}<br>Respect earned. Your actual wanted level remains unchanged.</p><button class="primary" id="play-again">Run it back <span>↻</span></button></div>`;
}
function restartGame(){clearInterval(gameInterval);game.active=false;game.complete=false;game.found=new Set();game.seconds=0;game.hints=0;$('#main').innerHTML=hunt();bindHunt()}
function runGameTimer(){clearInterval(gameInterval);if(!game.active||game.complete)return;game.start=performance.now()-game.seconds*1000;gameInterval=setInterval(()=>{game.seconds=Math.floor((performance.now()-game.start)/1000);if($('#game-time'))$('#game-time').textContent=fmt(game.seconds)},500)}
function bindHunt(){
 if($('#start-hunt'))$('#start-hunt').onclick=()=>{game.active=true;$('#main').innerHTML=hunt();bindHunt();runGameTimer();$('.game-object').focus()};
 if($('#play-again'))$('#play-again').onclick=restartGame;
 $('#restart-button').onclick=restartGame;
 $('#hint-button').disabled=!game.active||game.complete;
 $('#hint-button').onclick=()=>{const i=objects.findIndex((_,i)=>!game.found.has(i));if(i<0)return;game.hints++;const b=$(`[data-object="${i}"]`);b.classList.add('hinted');toast(`${objects[i].name}: ${objects[i].clue}`);$('#hint-button').textContent=`Get a hint (${game.hints})`};
 $$('[data-object]').forEach(b=>b.onclick=()=>{
  const i=+b.dataset.object;if(!game.active||game.complete||game.found.has(i))return;
  game.found.add(i);b.classList.add('found');b.classList.remove('hinted');b.setAttribute('aria-disabled','true');b.setAttribute('aria-label',objects[i].name+', collected');$('#found-count').textContent=game.found.size;const c=$(`[data-clue="${i}"]`);c.classList.add('collected');c.querySelector('strong').textContent=objects[i].name+'';toast(`${objects[i].name} collected. ${game.found.size} / 6.`);
  if(game.found.size===6){game.seconds=Math.floor((performance.now()-game.start)/1000);game.complete=true;game.active=false;clearInterval(gameInterval);game.best=game.best===null?game.seconds:Math.min(game.best,game.seconds);writeStore('best',game.best);$('.game-stage').insertAdjacentHTML('beforeend',completeOverlay());$('#play-again').onclick=restartGame;$('#play-again').focus();$('#hint-button').disabled=true}
 });
 if(game.active&&!game.complete)runGameTimer();
}
function homeAfterHours(){
 const chosen=['Comet S2 Cabriolet','Cheetah','Banshee'].map(n=>DATA.vehicles.find(v=>v.name===n&&v.image)).filter(Boolean);
 if(chosen.length<3)DATA.vehicles.filter(v=>v.image&&!chosen.includes(v)).slice(0,3-chosen.length).forEach(v=>chosen.push(v));
 const scenes=['assets/featured.webp','assets/music.webp','assets/media.webp'];
 return `<div class="view home-board"><div class="hero-grid"><section class="lead-tile"><img class="lead-image" src="${scenes[selectedScene]}" alt="${['Jason and Lucia beside a red car at sunset in Leonida','Jason and Lucia overlooking the Vice City skyline','Lucia and Jason in a heist scene'][selectedScene]}" fetchpriority="high"><div class="lead-caption"><a href="https://www.rockstargames.com/VI" target="_blank" rel="noopener">Grand Theft Auto VI ↗</a><span>Unofficial. Unfiltered. Always tuned in.</span></div><div class="scene-switch" role="group" aria-label="Artwork scenes">${['Sunset drive','City lights','The getaway'].map((n,i)=>`<button data-scene="${i}" class="${i===selectedScene?'selected':''}" aria-label="Show ${n}" aria-pressed="${i===selectedScene}"></button>`).join('')}</div><div class="lead-content"><h1>VICE CITY.<br>YOUR RULES.</h1><p>Your after-hours GTA VI fan hub. Find your getaway, chase the details, and turn the radio up.</p><div class="lead-actions"><a href="#vehicles" class="primary">Enter the garage <span>↗</span></a><a href="#hunt" class="plain-link">Take a side mission <span>↗</span></a></div></div></section><section class="home-radio" aria-label="Fan radio console"><div class="radio-thumb"><img src="assets/music.webp" alt="Jason and Lucia on a car with the Vice City skyline behind them"><button id="home-play" aria-label="${radio.playing?'Pause fan radio':'Play fan radio'}">${radio.playing?'Ⅱ':'▶'}</button></div><h2>NO DEAD AIR.</h2><p><strong id="home-song">${title()}</strong><br>Original instrumentals. Made for the long way home.</p><div class="station-picks" role="group" aria-label="Choose a fan station">${stations.map((s,i)=>`<button data-home-station="${i}" class="${i===radio.station?'selected':''}" aria-pressed="${i===radio.station}"><span class="station-name">${s.name}</span><span>${s.freq} FM ↗</span></button>`).join('')}</div><a href="#radio">Open the radio studio ↗</a></section></div><div class="jump-grid"><a href="#vehicles" class="jump-tile"><img src="assets/featured.webp" alt="" style="object-position:80% 85%"><span class="arrow">↗</span><div><h2>The garage.</h2><span>${DATA.vehicles.length} vehicles. Pick your escape.</span></div></a><a href="#weapons" class="jump-tile"><img src="assets/media.webp" alt=""><span class="arrow">↗</span><div><h2>The armory.</h2><span>${DATA.weapons.length} weapons. Know the evidence.</span></div></a><a href="#timeline" class="jump-tile pink"><span class="arrow">↗</span><div><h2>The long wait.</h2><span>Every reveal. Every revised plan.</span></div></a><a href="#hunt" class="jump-tile"><img src="assets/hero.webp" alt=""><span class="arrow">↗</span><div><h2>Look closer.</h2><span>Six secrets hiding in plain sight.</span></div></a></div><aside class="ticker"><p><strong>Next stop: Leonida.</strong>Currently scheduled for November 19, 2026.</p><a href="#timeline">Follow the paper trail ↗</a></aside><section class="section"><div class="section-head"><div><h2>Build your getaway.</h2><p>Something fast. Something loud. Something you probably shouldn’t leave unlocked.</p></div><a href="#vehicles">Explore all ${DATA.vehicles.length} vehicles ↗</a></div><div class="garage-teasers">${chosen.map(v=>`<button class="garage-teaser" data-featured-vehicle="${DATA.vehicles.indexOf(v)}" style="padding:0;text-align:left;color:inherit"><img src="${esc(v.image)}" alt="${esc(v.name)}" loading="lazy"><div class="teaser-copy"><span class="category">${esc(v.category)}</span><h3>${esc(v.name)}</h3>${statusHTML(v.status)}</div></button>`).join('')}</div></section><div class="two-up"><section class="side-mission"><img src="assets/hero.webp" alt="Classic GTA-style illustrated loading-screen collage" loading="lazy"><div><h2>Nothing to see.<br>Six things to find.</h2><p>An interactive loading screen. A pocketful of clues. Your next very unnecessary side quest.</p><a href="#hunt" class="primary">Start the hunt <span>↗</span></a></div></section><section class="release-card"><h2>THE WAIT.<br>ON RECORD.</h2><p>Announcements and delays, without the rumour fog. Follow the sourced road from “well underway” to the latest release target.</p><a href="#timeline" class="plain-link">Read the timeline <span>↗</span></a></section></div></div>`;
}
function radioPage(){
 const s=stations[radio.station],art=['assets/music.webp','assets/featured.webp','assets/media.webp'][radio.station];
 return `<div class="view"><section class="page-intro"><div><h1>NO DEAD AIR.</h1><p>Three independent fan stations. Twelve original instrumentals. One good reason to take the long way home.</p></div><div class="intro-stat">${s.freq}<span>FM / ORIGINAL FAN RADIO</span></div></section><div class="radio-page"><div class="radio-tabs" role="group" aria-label="Radio stations">${stations.map((v,i)=>`<button data-station="${i}" class="${radio.station===i?'selected':''}" aria-pressed="${radio.station===i}">${v.name}<span>${v.freq} FM</span></button>`).join('')}</div><div class="radio-studio"><div><section class="album-stage"><img src="${art}" alt="Official Rockstar artwork used as fan station cover art"><div><span class="freq">${s.freq} FM / FAN MIX</span><h2>${s.name}</h2><p>${s.tag}</p></div></section><div class="console"><label for="station-dial">Find your frequency</label><input type="range" id="station-dial" aria-label="Station tuner" min="0" max="2" step="1" value="${radio.station}"><span>${s.freq} FM</span></div><div class="spectrum-wrap" aria-label="Live audio frequency spectrum"><canvas id="spectrum" width="700" height="100" aria-hidden="true"></canvas><div class="spectrum-label"><span>${radio.playing?'Live audio spectrum':'Spectrum rests until you press play'}</span><span>Original synth session</span></div></div></div><section><div class="playlist-head"><h2>ON THE ROTATION.</h2><button id="shuffle" aria-pressed="${radio.shuffle}">Shuffle: ${radio.shuffle?'on':'off'}</button></div><p class="playlist-meta">${s.style} · 4 tracks · 6 min 24 sec</p><div id="playlist">${s.tracks.map((t,i)=>`<button class="track ${radio.track===i?'current':''}" data-track="${i}" aria-label="Play ${t[0]}"><span class="track-play">${radio.track===i&&radio.playing?'Ⅱ':i+1}</span><span><strong>${t[0]}</strong><small>Vice Signal house band · Original instrumental</small></span><span class="track-time">1:36</span></button>`).join('')}</div><div class="radio-title-action"><button class="primary" id="big-play">${radio.playing?'Pause the broadcast':'Start the broadcast'}<span>${radio.playing?'Ⅱ':'▶'}</span></button></div><p class="audio-status">${radio.playing?'You’re on the air.':'Ready whenever you are.'} Keep browsing. The music goes with you.</p></section></div><p class="radio-note">This is an independent fan mix, not an official GTA VI station list or soundtrack. All music is generated live as original 96-second instrumental loops. No external music streams.</p></div></div>`;
}
function showSavedGarage(){
 const list=DATA.vehicles.filter(v=>savedVehicles.has(v.name));
 modal(`<h2>Your getaway collection.</h2><p>${list.length?`${list.length} saved vehicle${list.length===1?'':'s'}. Open one for its evidence and details.`:'Your garage is empty. Open a vehicle and choose “Save to your garage” to start your collection.'}</p><div class="saved-grid">${list.map(v=>`<button data-saved-entry="${DATA.vehicles.indexOf(v)}"><span>${esc(v.name)}</span><span>↗</span></button>`).join('')}</div>`);
 $$('[data-saved-entry]').forEach(b=>b.onclick=()=>showEntry(DATA.vehicles[+b.dataset.savedEntry]));
}
function bindHome(){
 $('.side-mission h2').innerHTML='SIX SECRETS.<br>ZERO ALIBIS.';
 $('#home-play').onclick=()=>setPlaying(!radio.playing);
 $$('[data-home-station]').forEach(b=>b.onclick=()=>{radio.station=+b.dataset.homeStation;radio.track=0;radio.position=0;setPlaying(true)});
 $$('[data-scene]').forEach(b=>b.onclick=()=>{selectedScene=+b.dataset.scene;const img=$('.lead-image');img.src=['assets/featured.webp','assets/music.webp','assets/media.webp'][selectedScene];img.alt=['Jason and Lucia beside a car at sunset','Jason and Lucia overlooking Vice City','Jason and Lucia in a heist scene'][selectedScene];$$('[data-scene]').forEach(x=>{x.classList.toggle('selected',x===b);x.setAttribute('aria-pressed',x===b)})});
 $$('[data-featured-vehicle]').forEach(b=>b.onclick=()=>showEntry(DATA.vehicles[+b.dataset.featuredVehicle]));
}
setInterval(()=>{
 const canvas=$('#spectrum');if(!canvas)return;
 const ctx=canvas.getContext('2d'),w=canvas.width,h=canvas.height;ctx.clearRect(0,0,w,h);
 let values;
 if(radio.playing&&radio.ctx){if(!radio.analyser){radio.analyser=radio.ctx.createAnalyser();radio.analyser.fftSize=256;radio.master.connect(radio.analyser)}values=new Uint8Array(radio.analyser.frequencyBinCount);radio.analyser.getByteFrequencyData(values)}
 for(let i=0;i<48;i++){const height=values?Math.max(3,values[Math.floor(i*values.length/48)]/255*(h-5)):3;ctx.fillStyle=radio.playing?'#ffa3b5':'#4d4e58';ctx.fillRect(i*w/48,h-height,w/48-5,height)}
},70);
function route(){
 const r=location.hash.slice(1).split('?')[0]||'home';
 if(currentRoute==='hunt'){clearInterval(gameInterval);if(game.active)game.seconds=Math.floor((performance.now()-game.start)/1000)}
 currentRoute=['home','radio','vehicles','weapons','timeline','hunt'].includes(r)?r:'home';
 $$('[data-nav]').forEach(a=>{a.classList.toggle('active',a.dataset.nav===currentRoute);if(a.dataset.nav===currentRoute)a.setAttribute('aria-current','page');else a.removeAttribute('aria-current')});
 $('#main').innerHTML=currentRoute==='home'?homeAfterHours():currentRoute==='radio'?radioPage():currentRoute==='timeline'?timeline():currentRoute==='hunt'?hunt():roster(currentRoute);
 document.title=`${{home:'GTA VI Fan Hub',radio:'Fan Radio',vehicles:'Vehicle Archive',weapons:'Weapon Archive',timeline:'Announcement Timeline',hunt:'The Loading Screen Hunt'}[currentRoute]} • Vice Signal: After Hours`;
 if(currentRoute==='home')bindHome();
 if(['vehicles','weapons'].includes(currentRoute)){
  renderResults();const s=rosterState[currentRoute];
  $('#roster-search').oninput=e=>{s.q=e.target.value;s.limit=24;renderResults()};
  $('#class-filter').onchange=e=>{s.category=e.target.value;s.limit=24;renderResults()};
  $$('[data-status]').forEach(b=>b.onclick=()=>{s.status=b.dataset.status;s.limit=24;renderResults()});
  $('#load-more').onclick=()=>{s.limit+=24;renderResults()};
  if(currentRoute==='vehicles'){$('.filter-bar').insertAdjacentHTML('beforeend',`<button id="saved-garage">Saved garage (${savedVehicles.size})</button>`);$('#saved-garage').onclick=showSavedGarage}
 }
 if(currentRoute==='radio')bindRadio();
 if(currentRoute==='hunt')bindHunt();
 updatePlayer();scrollTo({top:0,behavior:'instant'});
 if(currentRoute==='timeline')$('.page-intro h1').textContent='THE LONG WAIT.';
 if(currentRoute==='hunt')$('.page-intro h1').textContent='THE LOADING SCREEN HUNT.';
 if('IntersectionObserver' in window){const observer=new IntersectionObserver(entries=>entries.forEach(e=>{if(e.isIntersecting){e.target.classList.add('in-view');observer.unobserve(e.target)}}),{threshold:.15});$$('.lead-content h1,.lead-content>p,.lead-actions,.radio-thumb,.home-radio h2,.home-radio>p,.jump-tile,.section-head,.garage-teaser,.side-mission,.release-card').forEach(e=>observer.observe(e))}
}
window.addEventListener('hashchange',route);route();
